SITE: Lumea Bufnițelor

Fișierul index.html este un site static, responsive, cu HTTPS posibil prin GitHub Pages, Netlify, Vercel etc.

IMPORTANT:
- Site-ul este pregătit pentru publicare, dar din această conversație nu pot crea direct un domeniu public HTTPS.
- Pentru publicare gratuită: urcă index.html într-un repository GitHub și activează Settings -> Pages -> Deploy from branch.
- Imaginile sunt ilustrații SVG originale incluse direct în HTML, deci nu depind de alte fișiere.

Surse de inspirație:
1. BBC Earth – Owl Facts: https://www.bbcearth.com/factfiles/animals/birds/owl
2. Encyclopædia Britannica – Owl: https://en.wikisource.org/wiki/1911_Encyclop%C3%A6dia_Britannica/Owl
